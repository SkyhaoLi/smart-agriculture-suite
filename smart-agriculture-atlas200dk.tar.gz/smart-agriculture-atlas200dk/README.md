# 智润智慧农业套件 - Atlas 200I DK A2 版

ESP32总坏？换吕布骑狗！华为昇腾Atlas 200I DK A2 驱动的智慧农业灌溉系统。

## 硬件平台

| 参数 | Atlas 200I DK A2 |
|------|-----------------|
| NPU | Ascend 310B, 8 TOPS (INT8) / 4 TFLOPS (FP16) |
| CPU | 4核 Cortex-A55 @ 1.0 GHz |
| 内存 | 4GB LPDDR4X (ECC) |
| 存储 | MicroSD + M.2 NVMe SSD |
| 操作系统 | Ubuntu 22.04 / openEuler 22.03 |
| 摄像头 | MIPI-CSI x2 (原生) |
| 显示 | HDMI x2 / MIPI-DSI |
| 扩展 | 40Pin GPIO (兼容树莓派引脚) |
| 功耗 | 24W 典型 |

## 与ESP32版的功能对比

| 功能 | ESP32-S3版 | Atlas 200I DK A2版 |
|------|-----------|-------------------|
| 开发语言 | C++ (Arduino) | Python 3 |
| 灌溉规则引擎 | ✅ | ✅ 完全一致 |
| 异常检测(Isolation Forest) | ✅ 手写C | ✅ NumPy加速 |
| Q-Learning | ✅ 手写C | ✅ NumPy加速 |
| 传感器融合(Kalman+NN) | ✅ 手写C | ✅ NumPy加速 |
| 作物生长跟踪 | ✅ | ✅ 完全一致 |
| 病害检测 | TFLite Micro (150KB arena) | **NPU 8TOPS / ONNX Runtime** |
| 摄像头 | DVP OV系列 96x96 | MIPI-CSI 全分辨率 |
| Web仪表盘 | ESP32 WebServer | Flask (多线程) |
| 显示 | SSD1306 I2C OLED | SSD1306 / HDMI / MIPI-DSI |
| 持久化 | NVS (ESP32) | JSON文件 |
| 离线运行 | ✅ | ✅ (无需网络) |
| OTA升级 | ✅ HTTP OTA | apt / scp |

## 40Pin 引脚分配

| 功能 | Atlas 40Pin | 说明 |
|------|------------|------|
| I2C7 SDA | Pin3 | BH1750光照 + SSD1306 OLED |
| I2C7 SCL | Pin5 | 同上 |
| I2C6 SDA | Pin27 | ADS1115 ADC (土壤/液位) |
| I2C6 SCL | Pin28 | 同上 |
| UART2 TX | Pin26 | 空气温湿度传感器 |
| UART2 RX | Pin31 | 同上 |
| 电磁阀 | Pin11 (GPIO17) | 需MOS/继电器驱动 |
| 水泵 | Pin13 (GPIO27) | 需MOS/继电器驱动 |
| 蜂鸣器 | Pin15 (GPIO22) | 有源蜂鸣器 |
| 摄像头 | MIPI-CSI 0/1 | 板载接口, 非GPIO |

**注意**: GPIO输出需外置1K~10K上拉电阻增强驱动能力

## 快速开始

```bash
# 1. 安装依赖
cd smart-agriculture-atlas200dk
bash tools/install.sh

# 2. 启动 (纯灌溉控制模式)
python3 main.py

# 3. 启动 (灌溉+摄像头模式)
python3 main.py --profile 2

# 4. 启动 (摄像头优先模式)
python3 main.py --profile 3

# 5. 访问Web仪表盘
浏览器打开 http://<Atlas IP>:8080
```

## NPU病害检测模型部署

Atlas 200I DK A2 的 Ascend 310B 提供 8 TOPS INT8 算力，推理能力远超ESP32:

```bash
# 1. 将原TFLite模型转为ONNX (在PC上操作)
python3 tools/convert_model.py --input plant_disease_model.tflite --output plant_disease_model.onnx

# 2. 将ONNX转为OM (在Atlas板上操作, 需安装ATC工具)
atc --model=plant_disease_model.onnx \
    --output=plant_disease_model.om \
    --framework=5 \
    --soc=Ascend310B1

# 3. 将OM模型放入模型目录
cp plant_disease_model.om /opt/agri-atlas/models/
```

## 项目结构

```
smart-agriculture-atlas200dk/
├── main.py                    # 主入口 (对应原 main.cpp)
├── requirements.txt           # Python依赖
├── config/
│   ├── __init__.py
│   ├── hardware_config.py     # 引脚映射 + 系统常量 (对应 AppConfig.h)
│   └── app_types.py           # 共享数据类型 (对应 AppTypes.h)
├── src/
│   ├── sensors/
│   │   └── sensor_hub.py      # 5路传感器 (UART/I2C/ADC)
│   ├── actuators/
│   │   └── actuator_controller.py  # GPIO执行器 (gpiod)
│   ├── ai/
│   │   ├── irrigation_module.py    # 灌溉规则引擎
│   │   ├── anomaly_module.py       # 三层异常检测
│   │   ├── growth_module.py        # 作物生长跟踪
│   │   ├── learning_module.py      # Q-Learning
│   │   ├── fusion_module.py        # 传感器融合
│   │   └── plant_doctor_module.py  # NPU病害检测
│   ├── display/
│   │   └── display_module.py       # OLED/终端显示
│   └── web/
│       └── dashboard.py            # Flask REST API
├── tools/
│   ├── install.sh             # 一键安装
│   └── agri-atlas.service     # systemd服务
├── models/                    # AI模型文件 (.om/.onnx)
└── docs/
```

## API接口 (与ESP32版完全兼容)

| 路径 | 方法 | 说明 |
|------|------|------|
| `/api/status` | GET | 总体状态 |
| `/api/irrigation/status` | GET | 灌溉+传感器+执行器 |
| `/api/irrigation/mode` | POST | 切换自动/手动 |
| `/api/irrigation/pump` | POST | 手动开关水泵 |
| `/api/anomaly/status` | GET | 异常检测状态 |
| `/api/growth/status` | GET | 生长跟踪 |
| `/api/learning/status` | GET | Q-Learning状态 |
| `/api/fusion/status` | GET | 传感器融合 |
| `/api/plant/status` | GET | 病害检测状态 |
| `/api/plant/detect` | GET | 手动触发检测 |
| `/api/plant/capture` | GET | 拍照 (返回JPEG) |

...以及其他所有ESP32版API，完全兼容。
